import org.snmp4j.PDU;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

import java.io.IOException;

/*
*
*   objetos usados: ifIndex
*                   ifDescr
*                   ifPhysAddress
*                   ifInOctets
*                   ifOutOctets
*                   ifAdminStatus
*/
public class TestClass {
    public static void main(String args[]) throws IOException {
     ConfigFileParser configFile = new ConfigFileParser();
     int status = configFile.openConfigFile();

        System.out.println("Status: " + Vars.LOG_MESSAGES[status]);
        //System.out.println(configFile.toString());
    }
}